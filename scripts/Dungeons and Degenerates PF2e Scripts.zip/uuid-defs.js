// uuid-defs.js

export const UUIDS = {
  // 🩸 Arousal Effects
  AROUSED: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.XNV88VOFYRAITYKd",
  CUMMING: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.PoJvmGQcQer3FqcS",
  EJACULATING: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.nZkcL44Mgpj8KX2V",
  ORGASM_FATIGUE: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.spjN1Txh2QOtFhhy",

  // 🍳 Fertility & Reproduction Effects
  OVULATING: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.FI6dPO2xT2XKISZm",
  CUM_BELLY: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.JixEgUhMpGY46PZw",

  // 👕 Clothing & Exposure Effects
  EXPOSED_BREASTS: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.d6JWHUM6pPTEDGA7",
  EXPOSED_GENITALS: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.7sJlUb76AH1Ou1AM",
  NAKED: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.U9Rr1judY347qejU",
  SPERM_COVER_PELVIS: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.oo3HQ8xNzBnC8Ssi",
  SPERM_COVER_ABDOMEN: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.6PUqRUH0xo2uhN70",
  SPERM_COVER_CHEST: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.TufhP8k96JOWT2mT",
  SPERM_COVER_FACE: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.hpvPpXEi7dDUWFQp",

  // Intercourse Effects
  RAPING_PUSSY: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.RypwYsb6Wa5Krlb5",
  RAPING_ANAL: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.5OPflLUtwCSp4HXa",
  RAPING_ORAL: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.ysIez78GY3NtYHhY",
  RAPING_BREASTS: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.PKeyC1upnE48VKI2",
  RAPED_PUSSY: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.1sZ21WLt5LhDuP3Q",
  RAPED_ANAL: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.kEclZCdG8CK9Jj8I",
  RAPED_ORAL: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.Pn4H2jRQ7jSRRZZH",
  RAPED_BREASTS: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.BcNZOzlWeLjU9Gzb",
  WOMBFUCKING: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.bdv9yofrOKERkBZp",
  WOMBFUCKED: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.iwCbUUPmfiX3pM0k",
  

  // Actions
  PENETRATE: "Compendium.dungeons-and-degenerates-pf2e.degenerate-actions.Item.UG0NkM1T0LcWPuv4",
  RAPE: "Compendium.dungeons-and-degenerates-pf2e.degenerate-actions.Item.42MZ3mfN2tirLeXu",
  STRIP: "Compendium.dungeons-and-degenerates-pf2e.degenerate-actions.Item.EGfNFQTMSsrDAsmB",
  FONDLE: "Compendium.dungeons-and-degenerates-pf2e.degenerate-actions.Item.FiVR3EwTBqb6JPQe",
  GRAPPLE: "Compendium.dungeons-and-degenerates-pf2e.degenerate-actions.Item.ZER0WRoqMcrMnmNl",
  ATTACH: "Compendium.dungeons-and-degenerates-pf2e.degenerate-actions.Item.kHLc6qNnff1m9yUK"
};

  // Planned future effects:
  // "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.cumbellyUUID",
  // WOMB_FULL: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.wombfullUUID",
  // MILK_DRUNK: "Compendium.dungeons-and-degenerates-pf2e.degenerate-effects.Item.milkdrunkUUID"

